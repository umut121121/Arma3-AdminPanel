<?php
session_start();
ob_start();

if (!isset($_SESSION['logged'])) {
    header('Location: index.php');
    die();
}

$staffPerms = $_SESSION['perms'];
$user = $_SESSION['user'];

if ($staffPerms['notes'] != '1') {
    header('Location: lvlError.php');
    die();
}

include 'verifyPanel.php';
masterconnect();

if (isset($_POST['search'])) {
    $valuetosearch = mysqli_real_escape_string($dbcon, $_POST['SearchValue']);
    $sqlget = "SELECT * FROM notes WHERE CONCAT (`name`) LIKE '%".$valuetosearch."%' ORDER BY note_id DESC";
    $search_result = filterTable($dbcon, $sqlget);
} else {
    $sqlget = 'SELECT * FROM notes ORDER BY note_id DESC';
    $search_result = filterTable($dbcon, $sqlget);
}

if (isset($_POST['update'])) {
    $noteID = $_POST['note_id'];
    $uid = $_POST['uid'];
    $name = $_POST['name'];
    $text = $_POST['note_text'];
    $admin = $_POST['admin'];

    if ($staffPerms['superUser'] == '1') {
        $sql = "DELETE FROM notes WHERE note_id='$noteID'";
        mysqli_query($dbcon, $sql);
        $message = 'Note ('.$text.') kullanıcıya yerleştirilir ('.$name.' ID - '.$uid.') by '.$admin.' tarafından silindi '.$user;
        logIt($user, $message, $dbcon);
    } else {
        $message = 'Note ('.$text.') kullanıcıya yerleştirilir ('.$name.' ID - '.$uid.') by '.$admin.' tarafından silinmeye çalışıldı '.$user;
        logIt($user, $message, $dbcon);
    }
}
include 'header/header.php';
?>

<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
<h1 style = "margin-top: 70px">Notlar Görünümü</h1>
<p class="page-header">Notlar Görünümü, ayarlanan tüm notları görmenizi sağlar.</p>

<div class="btn-group" role="group" aria-label="...">
<FORM METHOD="LINK" ACTION="players.php">
<INPUT class='btn btn-primary btn-outline' TYPE="submit" VALUE="Geri">
</FORM>
</div>


<form action = "notesView.php" method="post">
		  <div class ="searchBar">
			<div class="row">
			  <div class="col-lg-6">
				<div class="input-group">
				  <input type="text" class="form-control" style = "width: 300px; " name="SearchValue" placeholder="Oyuncu adı...">
				  <span class="input-group-btn">
					<input class="btn btn-default"  name="search" type="submit" value="Ara">
				  </span>
				</div><!-- /input-group -->
			  </div><!-- /.col-lg-6 -->
			</div><!-- /.row -->
		  </div>
</form>

			<br>


          <div class="table-responsive">
            <table class="table table-striped" style = "margin-top: -10px">
              <thead>
                <tr>
                    <th>Oyuncu ID</th>
                    <th>Oyuncu</th>
                    <th>Oyuncu Alias</th>
                    <th>Oyuncu Not</th>
                    <th>Personel Üyesi</th>
                    <th>Zaman</th>
                    <th>Sil</th>
                </tr>
              </thead>
              <tbody>
<?php
while ($row = mysqli_fetch_array($search_result, MYSQLI_ASSOC)) {
    echo '<form action=notesView.php method=post>';
    switch ($row['warning']) {
        default:
            echo '<tr>';
            break;
        case 2:
            echo '<tr class = "warning">';
            break;
        case 3:
            echo '<tr class = "danger">';
            break;
        case 4:
            echo '<tr class = "success">';
            break;
    }
    echo '<td>'.htmlspecialchars($row['uid'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'.htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'.htmlspecialchars($row['alias'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'.htmlspecialchars($row['note_text'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'.htmlspecialchars($row['staff_name'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'.htmlspecialchars($row['note_updated'], ENT_QUOTES, 'UTF-8').' </td>';
    echo '<td>'."<input class='btn btn-primary btn-outline' type=submit name=update value=Sil".' </td>';
    echo "<td style='display:none;'>".'<input type=hidden name=note_id value='.htmlspecialchars($row['note_id'], ENT_QUOTES, 'UTF-8').' </td>';
    echo "<td style='display:none;'>".'<input type=hidden name=uid value='.htmlspecialchars($row['uid'], ENT_QUOTES, 'UTF-8').' </td>';
    echo "<td style='display:none;'>".'<input type=hidden name=name value='.htmlspecialchars($row['name'], ENT_QUOTES, 'UTF-8').' </td>';
    echo "<td style='display:none;'>".'<input type=hidden name=note_text value='.htmlspecialchars($row['note_text'], ENT_QUOTES, 'UTF-8').' </td>';
    echo "<td style='display:none;'>".'<input type=hidden name=admin value='.htmlspecialchars($row['staff_name'], ENT_QUOTES, 'UTF-8').' </td>';

    echo '</tr>';
    echo '</form>';
}

echo '</table></div>';
?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="dist/js/bootstrap.min.js"></script>
    <!-- Just to make our placeholder images work. Don't actually copy the next line! -->
    <script src="../../assets/js/vendor/holder.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
