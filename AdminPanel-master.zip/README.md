<a href="https://discord.gg/G4G3Jrm6z2">
    <img src="https://img.shields.io/badge/Discord-Join%20chat%20→-738bd7.svg" alt="Join the chat at https://discord.gg/G4G3Jrm6z2">		 
</a>


## AdminPanel Info
Arma 3 admin panel ingilizce yönetim panelidi bende türkçe yönetim paneli yaptım umarım beğenirseniz

%90 Türkçe

İyi kullanımlar sorun olursa bana yazmayı unutma

### Screenshots

Bu panel görüntüleri <a href = "https://www.flickr.com/photos/140721778@N03/albums/72157667459890313">Görüntüler!</a>

### Install

Bu dosyaları bir web sunucusuna bırakın. Diğer her şey panelin kendisinden yapılandırılmıştır, bu nedenle dosya yapılandırmasına gerek yoktur!
Not - DB bilgisi, Arma 3 Altis Life Veri tabanıdır.

Varsayılan kullanıcı Adı: AdminPanel Şifresi: Admin1234 
Lütfen ilk girişten sonra bunu değiştirin.